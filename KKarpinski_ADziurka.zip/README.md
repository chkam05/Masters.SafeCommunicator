# SafeCommunicator
W ramach projektu nalezy zaimplementowac algorytm Rivesta-Shamira-Adlemana RSA oraz algorytm ElGamala. Wspomniane szyfry powinny zostac zaaplikowane do prostego komunikatora słuzacego do konwersacji pomiedzy dwoma uzytkownikami.
