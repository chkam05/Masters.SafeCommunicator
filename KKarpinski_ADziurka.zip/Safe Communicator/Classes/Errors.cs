﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Safe_Communicator.Classes {

    public enum Errors {
        NO_ERROR        =   0,
        INVALID_FORMAT  =   1,
        INVALID_RANGE   =   2,
    }
    
}
