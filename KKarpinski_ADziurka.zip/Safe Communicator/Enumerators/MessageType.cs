﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Safe_Communicator.Enumerators {

    // ####################################################################################################
    //  x   x   xxxxx    xxxx    xxxx    xxx     xxxx   xxxxx      xxxxx   x   x   xxxx    xxxxx
    //  xx xx   x       x       x       x   x   x       x            x     x   x   x   x   x    
    //  x x x   xxxx     xxx     xxx    xxxxx   x  xx   xxxx         x      xxx    xxxx    xxxx 
    //  x   x   x           x       x   x   x   x   x   x            x       x     x       x    
    //  x   x   xxxxx   xxxx    xxxx    x   x    xxxx   xxxxx        x       x     x       xxxxx
    // ####################################################################################################
    enum MessageType {
        CLIENT,
        SERVER
    }

    // ####################################################################################################
}
