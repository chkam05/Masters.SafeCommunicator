﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Safe_Communicator.Crypt {

    public enum CryptType {
        None    =   0,
        RSA     =   1,
        ElGamal =   2
    }

}
